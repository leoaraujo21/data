const CAMUNDA_BASE_URL = "http://localhost:8082/engine-rest";
// const DEPLOYMENT_ID = "c6c22856-1189-11f0-86a9-0242ac1c0004";
const DEPLOYMENT_IDs = [
    "1f428d10-1721-11f0-9689-0242ac1c0002"
];

async function deleteInstancesByDeploymentId(DEPLOYMENT_ID: string) {
    console.log(`Deletando instâncias do deployment ${DEPLOYMENT_ID}...`);
    const definitions = await fetch(`${CAMUNDA_BASE_URL}/process-definition?deploymentId=${DEPLOYMENT_ID}`)
        .then(res => res.json());

    for (const def of definitions) {
        const instances = await fetch(`${CAMUNDA_BASE_URL}/process-instance?processDefinitionId=${def.id}`)
            .then(res => res.json());

        console.log(`Encontradas ${instances.length} instâncias do processo ${def.key}`);
        const ids = instances.map((inst: any) => inst.id);
        if (ids.length === 0) continue;

        await fetch(`${CAMUNDA_BASE_URL}/process-instance/delete`, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
                processInstanceIds: ids,
                skipCustomListeners: true,
                skipSubprocesses: true,
            }),
        });

        console.log(`Deletadas ${ids.length} instâncias do processo ${def.key}`);
    }
}

async function main() {
    for (const DEPLOYMENT_ID of DEPLOYMENT_IDs) {
        await deleteInstancesByDeploymentId(DEPLOYMENT_ID);
    }
}

main().catch(err => {
    console.error("Erro:", err.message);
    process.exit(1);
});
